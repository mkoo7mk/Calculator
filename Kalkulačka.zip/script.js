const input = document.getElementById('display');
const end = input.value.length;
input.setSelectionRange(end, end);
input.focus();
